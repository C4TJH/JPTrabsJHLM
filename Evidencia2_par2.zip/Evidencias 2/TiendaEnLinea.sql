CREATE DATABASE IF NOT EXISTS TiendaEnLinea;
USE TiendaEnLinea;

CREATE TABLE IF NOT EXISTS clientes (
id_cliente INT PRIMARY KEY,
nombre_cliente VARCHAR(20) NOT NULL,
correo_cliente VARCHAR(40) NOT NULL

);

CREATE TABLE IF NOT EXISTS pedidos (
id_pedido INT PRIMARY KEY AUTO_INCREMENT,
unidades INT NOT NULL,
fecha_pedido DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS productos (
id_producto INT PRIMARY KEY AUTO_INCREMENT,
nombre_prodcuto VARCHAR(20) NOT NULL,
descripcion_producto TEXT NOT NULL,
precio_producto DECIMAL(10,2) NOT NULL

);

CREATE TABLE IF NOT EXISTS registros (
id_registro INT PRIMARY KEY AUTO_INCREMENT,
id_pedido INT NOT NULL,
id_producto INT NOT NULL,

CONSTRAINT fk_registro_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido),
CONSTRAINT fk_registro_producto FOREIGN KEY (id_producto) REFERENCES productos(id_producto)

);