CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE IF NOT EXISTS usuarios (
numero_de_usuario INT PRIMARY KEY,
direccion_de_usuario TEXT NOT NULL,
nombre_de_usuario TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS libros (
codigo_libro INT PRIMARY KEY,
titulo_libro VARCHAR(30) NOT NULL,
autor_libro VARCHAR(10) NOT NULL,
año_publicacion DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS prestamos (
id_pretamo INT PRIMARY KEY,
fecha_de_inicio DATE NOT NULL,
fecha_limite DATE NOT NULL,
codigo_libro INT NOT NULL,
numero_de_usuario INT NOT NULL,

CONSTRAINT fk_prestamo_libro FOREIGN KEY (codigo_libro) REFERENCES libros(codigo_libro),
CONSTRAINT fk_prestamo_usuario FOREIGN KEY (numero_de_usuario) REFERENCES usuarios(numero_de_usuario)

);