CREATE DATABASE IF NOT EXISTS universidad;
USE universidad;

CREATE TABLE IF NOT EXISTS estudiantes (
numero_matricula INT PRIMARY KEY,
correo_estudiante VARCHAR(50) NOT NULL,
nombre_estudiante VARCHAR(30) NOT NULL
);

CREATE TABLE IF NOT EXISTS profesores (
codigo_de_profesor INT PRIMARY KEY,
especialidad VARCHAR(15) NOT NULL,
nombre_de_profesor VARCHAR(39) NOT NULL
);

CREATE TABLE IF NOT EXISTS Cursos (
codigo_de_curso INT PRIMARY KEY,
numero_de_creditos INT NULL,
nombre_de_curso VARCHAR(20) NOT NULL,
codigo_de_profesor INT NOT NULL,

CONSTRAINT fk_curso_profesor FOREIGN KEY (codigo_de_profesor) REFERENCES profesores(codigo_de_profesor)
);

CREATE TABLE IF NOT EXISTS estudiante_curso (
    c_inscripcion INT PRIMARY KEY,
    numero_matricula INT NOT NULL,
    codigo_de_curso INT NOT NULL,

    CONSTRAINT fk_estudiante_curso_curso FOREIGN KEY (codigo_de_curso) REFERENCES Cursos(codigo_de_curso),
    CONSTRAINT fk_estudiante_curso_estudiante FOREIGN KEY (numero_matricula) REFERENCES estudiantes(numero_matricula)
);
