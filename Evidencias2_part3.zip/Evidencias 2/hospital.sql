CREATE DATABASE IF NOT EXISTS Hospital;
USE Hospital;

CREATE TABLE IF NOT EXISTS pacientes (
n_historia_clinica INT PRIMARY KEY,
telefono_paciente VARCHAR(15)  NOT NULL,
nombre_paciente VARCHAR(20),
direccion_paciente VARCHAR(40)

);


CREATE TABLE IF NOT EXISTS medicos (
n_colegiatura INT PRIMARY KEY,
nombre_medico VARCHAR(40) NOT NULL,
especialidad VARCHAR(30) NOT NULL

);


CREATE TABLE IF NOT EXISTS citas (
id_cita INT PRIMARY KEY,
fecha_cita DATE NOT NULL,
hora_cita TIME NOT NULL,
nombre_paciente VARCHAR(20),
direccion_paciente VARCHAR(40),


n_historia_clinica INT NOT NULL,
n_colegiatura INT NOT NULL,

CONSTRAINT fk_cita_paciente FOREIGN KEY (n_historia_clinica) REFERENCES pacientes(n_historia_clinica),
CONSTRAINT fk_cita_medico FOREIGN KEY (n_colegiatura) REFERENCES medicos(n_colegiatura)

);