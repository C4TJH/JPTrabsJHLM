CREATE DATABASE IF NOT EXISTS TECH_ON_LINE;
USE TECH_ON_LINE;


CREATE TABLE IF NOT EXISTS Medios_de_Pago (
    id_pago INT PRIMARY KEY AUTO_INCREMENT,
    nombre_medio VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS clientes (
id_cliente INT PRIMARY KEY AUTO_INCREMENT,
n_identificacion INT NOT NULL UNIQUE,
nombre1 VARCHAR(50) NOT NULL,
nombre2 VARCHAR(50) NULL,
apellido1 VARCHAR(50) NOT NULL,
apellido2 VARCHAR(50) NULL
);

CREATE TABLE IF NOT EXISTS perfiles (
id_cliente INT PRIMARY KEY,
direccion VARCHAR(70) NOT NULL,
telefono VARCHAR(10) NOT NULL UNIQUE,
correo VARCHAR(40) NOT NULL,
fecha_de_nacimiento DATE NOT NULL,

CONSTRAINT fk_perfiles_clientes FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente)
);


CREATE TABLE IF NOT EXISTS proveedores (
id_proveedor INT PRIMARY KEY AUTO_INCREMENT,
nombre_empresa VARCHAR(100) NOT NULL UNIQUE,
nombre_contacto VARCHAR(50) NOT NULL,
telefono_empresa VARCHAR(15) NOT NULL,
correo_empresa VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS productos (
id_producto INT PRIMARY KEY AUTO_INCREMENT,
nombre_producto VARCHAR(100) NOT NULL UNIQUE,
precio_unitario DECIMAL(10,2) NOT NULL,
stock INT NOT NULL,
id_proveedor INT NOT NULL,

CONSTRAINT fk_productos_proveedores FOREIGN KEY (id_proveedor) REFERENCES proveedores(id_proveedor)
);

CREATE TABLE IF NOT EXISTS pedidos (
id_pedido INT PRIMARY KEY AUTO_INCREMENT,
id_cliente INT NOT NULL,
id_pago INT NOT NULL,
fecha_pedido DATE NOT NULL,

CONSTRAINT fk_pedidos_clientes FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
CONSTRAINT fk_pedidos_mediosdepago FOREIGN KEY (id_pago) REFERENCES Medios_de_Pago(id_pago)
);

CREATE TABLE IF NOT EXISTS detalles_pedidos (
id_pedido INT NOT NULL ,
id_producto INT NOT NULL, 
cantidad INT NOT NULL,
precio_unitario_venta DECIMAL(10.2) NOT NULL,

PRIMARY KEY(id_pedido, id_producto),

CONSTRAINT fk_detalles_pedidos FOREIGN KEY (id_pedido) REFERENCES pedidos (id_pedido),
CONSTRAINT fk_detalles_productos FOREIGN KEY (id_producto) REFERENCES productos (id_producto)

);

INSERT INTO Medios_de_Pago (nombre_medio) VALUES 
('Tarjeta de Crédito'), 
('Transferencia Bancaria'), 
('Efectivo'), 
('PayPal'), 
('Criptomoneda'),
('Débito Bancario'),
('Transferencia PSE'),
('Tarjeta de Regalo'),
('Bono Sodexo'),
('CASH On Delivery'),
('Nequi'),
('DaviPlata'),
('Punto Pago'),
('Billetera Virtual A'),
('Billetera Virtual B');

INSERT INTO proveedores (nombre_empresa, nombre_contacto, telefono_empresa, correo_empresa) VALUES 
('TechNova Distribuidores1', 'Laura Gómez', '555-1001', 'lgomez@tech.com'),
('CompuParts S.A.', 'Ricardo Paz', '555-1002', 'rpaz@compuparts.com'),
('Global Telecom S.R.L.', 'Sofía Ríos', '555-1003', 'srios@globaltel.com'),
('Accel Accessories', 'Juan Díaz', '555-1004', 'jdiaz@accelacc.com'),
('PowerChips Ltda.', 'Martín Soler', '555-1005', 'msoler@powerchips.com'),
('ElectroGadget Corp.', 'Felipe Ortiz', '555-1006', 'fortiz@electrogad.com'),
('Software Solutions Inc.', 'Diana Soto', '555-1007', 'dsoto@softsol.com'),
('Cable & Wireless Global', 'Héctor Vidal', '555-1008', 'hvidal@cablew.com'),
('ErgoTech Muebles', 'Isabel Mesa', '555-1009', 'imesa@ergotech.com'),
('Secure Data Systems', 'Pedro Leal', '555-1010', 'pleal@secured.com'),
('Mobile Accessories Pro', 'Giselle Paz', '555-1011', 'gpaz@mobipro.com'),
('Gaming Zone Ltda.', 'Luis Rey', '555-1012', 'lrey@gamingzone.com'),
('Storage Unlimited', 'Marta Soto', '555-1013', 'msoto@storageun.com'),
('Visual Displays Co.', 'Nelson Cruz', '555-1014', 'ncruz@visuald.com'),
('Cloud Services Partner', 'Oscar Vera', '555-1015', 'overa@cloudsp.com');


INSERT INTO Clientes (n_identificacion, nombre1, nombre2, apellido1, apellido2) VALUES
(1001, 'Ana', NULL, 'García', 'López'),
(1002, 'Carlos', 'Andrés', 'Rodríguez', 'Pérez'),
(1003, 'Sofía', NULL, 'Martínez', NULL),
(1004, 'David', 'José', 'Sánchez', 'Vargas'),
(1005, 'Elena', NULL, 'Ríos', 'Castro'),
(1006, 'Javier', 'Ignacio', 'Herrera', 'Arias'),
(1007, 'Luisa', NULL, 'Ramírez', 'Muñoz'),
(1008, 'Miguel', 'Ángel', 'Vásquez', 'Cruz'),
(1009, 'Natalia', NULL, 'Paredes', 'Rojas'),
(1010, 'Omar', 'Felipe', 'Quintero', 'Soto'),
(1011, 'Paula', NULL, 'Mendoza', 'Gil'),
(1012, 'Ricardo', 'Antonio', 'Torres', 'León'),
(1013, 'Valeria', NULL, 'Rueda', 'Díaz'),
(1014, 'William', 'Alex', 'Zamora', 'Vega'),
(1015, 'Yolanda', NULL, 'Núñez', 'Bravo');


INSERT INTO Perfiles (id_cliente, direccion, telefono, correo, fecha_de_nacimiento) VALUES
(1, 'Calle Falsa 123', '555-9999', 'ana.garcia@mail.com', '1990-05-15'),
(2, 'Avenida Central 45', '555-8888', 'carlos.r@mail.com', '1985-11-20'),
(3, 'Blvd. Libertad 78', '555-7777', 'sofia.m@mail.com', '1995-03-01'),
(4, 'Carrera 10 Este', '555-6666', 'david.s@mail.com', '1978-08-25'),
(5, 'Paseo del Sol 22', '555-5555', 'elena.r@mail.com', '1992-01-10'),
(6, 'Carrera 45 # 10-2B', '555-5006', 'javier.h@mail.com', '1993-02-18'),
(7, 'Calle 22 Sur # 5-11', '555-5007', 'luisa.r@mail.com', '1987-07-29'),
(8, 'Av. Circunvalar 3-A', '555-5008', 'miguel.v@mail.com', '1998-11-05'),
(9, 'Km 2 Vía al Mar', '555-5009', 'natalia.p@mail.com', '2000-04-12'),
(10, 'Diagonal 80 # 15-C', '555-5010', 'omar.q@mail.com', '1975-09-03'),
(11, 'Transversal 50 # 8-3D', '555-5011', 'paula.m@mail.com', '1991-01-22'),
(12, 'Calle 100 # 20-E', '555-5012', 'ricardo.t@mail.com', '1983-06-14'),
(13, 'Avenida 7 # 1-P', '555-5013', 'valeria.r@mail.com', '1996-03-08'),
(14, 'Barrio La Montaña', '555-5014', 'william.z@mail.com', '1970-12-01'),
(15, 'Conjunto Los Álamos', '555-5015', 'yolanda.n@mail.com', '1989-10-17');

INSERT INTO Productos (nombre_producto, precio_unitario, stock, id_proveedor) VALUES 
('Laptop Ultrabook X', 1250.00, 50, 1),
('Mouse Óptico Gamer', 35.50, 150, 2),
('Teléfono Galaxy Z', 899.99, 30, 3),
('Adaptador USB-C', 15.00, 200, 4),
('Memoria RAM 16GB', 80.00, 80, 5),
('Monitor Curvo 27"', 350.00, 40, 6),
('Tarjeta Gráfica RTX', 799.50, 25, 7),
('Auriculares Bluetooth', 45.99, 180, 8),
('Router WiFi 6', 89.00, 100, 9),
('Webcam 4K HD', 55.00, 90, 10),
('Silla Gamer Ergonómica', 220.00, 35, 11),
('Cable HDMI 2.1', 12.50, 300, 12),
('Disco SSD 1TB', 65.00, 110, 13),
('Teclado Mecánico RGB', 95.00, 75, 14),
('Mousepad XL', 18.00, 250, 15);

INSERT INTO Pedidos (id_cliente, id_pago, fecha_pedido) VALUES
(1, 1, '2025-10-01'),
(2, 2, '2025-10-05'),
(3, 3, '2025-10-10'),
(4, 4, '2025-10-15'),
(5, 5, '2025-10-20'),
(6, 6, '2025-10-22'),
(7, 7, '2025-10-23'),
(8, 8, '2025-10-24'),
(9, 9, '2025-10-25'),
(10, 10, '2025-10-26'),
(11, 11, '2025-10-27'),
(12, 12, '2025-10-28'),
(13, 13, '2025-10-29'),
(14, 14, '2025-10-30'),
(15, 15, '2025-10-31');

SELECT nombre_producto, precio_unitario, stock FROM Productos
ORDER BY nombre_producto ASC;

SELECT c.nombre1, c.apellido1, p.fecha_de_nacimiento FROM Clientes c JOIN Perfiles p ON c.id_cliente = p.id_cliente WHERE p.fecha_de_nacimiento < '1990-01-01' ORDER BY p.fecha_de_nacimiento DESC;

SELECT p.nombre_producto, pr.nombre_empresa AS Proveedor_Principal FROM Productos p JOIN Proveedores pr ON p.id_proveedor = pr.id_proveedor WHERE p.stock < 50;

SELECT id_pedido, SUM(cantidad * precio_unitario_venta) AS Valor_Total_Pedido FROM Detalle_Pedido GROUP BY id_pedido ORDER BY Valor_Total_Pedido DESC;

SELECT c.nombre1, p.fecha_pedido, mp.nombre_medio AS Metodo_de_Pago FROM Pedidos p JOIN Clientes c ON p.id_cliente = c.id_cliente JOIN Medios_de_Pago mp ON p.id_pago = mp.id_pago WHERE c.id_cliente = 5;


