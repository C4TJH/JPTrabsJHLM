CREATE DATABASE IF NOT EXISTS ClInica_Vida_Sana;
USE ClInica_Vida_Sana;

CREATE TABLE IF NOT EXISTS pacientes (
id_paciente INT PRIMARY KEY AUTO_INCREMENT,
n_identificacion VARCHAR(20) NOT NULL UNIQUE,
nombre1 VARCHAR(50) NOT NULL,
nombre2 VARCHAR(50) NULL,
apellido1 VARCHAR(50) NOT NULL,
apellido2 VARCHAR(50) NULL,
fecha_nacimiento DATE NOT NULL,
telefono_paciente VARCHAR(15) NOT NULL,
direccion_paciente VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Especialidades (
id_especialidad INT PRIMARY KEY AUTO_INCREMENT,
nombre_especialidad VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Medicos (
id_medico INT PRIMARY KEY AUTO_INCREMENT,
n_colegiado VARCHAR(20) NOT NULL UNIQUE,
nombre1 VARCHAR(50) NOT NULL,
nombre2 VARCHAR(50) NULL,
apellido1 VARCHAR(50) NOT NULL,
apellido2 VARCHAR(50) NULL,
telefono VARCHAR(15) NOT NULL,
id_especialidad INT NOT NULL,

CONSTRAINT fk_medico_especialidad FOREIGN KEY (id_especialidad) REFERENCES Especialidades(id_especialidad)
);

CREATE TABLE IF NOT EXISTS Citas (
id_cita INT PRIMARY KEY AUTO_INCREMENT,
id_paciente INT NOT NULL,
id_medico INT NOT NULL,
fecha_hora DATETIME NOT NULL,
motivo VARCHAR(200) NOT NULL,
diagnostico VARCHAR(500) NULL, -- Se guarda el resultado de la consulta

CONSTRAINT fk_cita_paciente FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente),
	
CONSTRAINT fk_cita_medico FOREIGN KEY (id_medico) REFERENCES Medicos(id_medico)
);

INSERT INTO Especialidades (nombre_especialidad) VALUES
('Cardiología'),
('Dermatología'),
('Pediatría'),
('Neurología'),
('Ginecología'),
('Odontología'),
('Urología'),
('Oftalmología'),
('Traumatología'),
('Psiquiatría'),
('Medicina General'),
('Endocrinología'),
('Gastroenterología'),
('Rehabilitación'),
('Otorrinolaringología');

INSERT INTO Pacientes (n_identificacion, nombre1, nombre2, apellido1, apellido2, fecha_nacimiento, telefono_paciente, direccion_paciente) VALUES
('2001', 'Laura', 'Sofía', 'Pérez', 'Gómez', '1995-07-20', '3101234567', 'Calle 10 # 5-20'),
('2002', 'Ricardo', NULL, 'Márquez', 'Soto', '1980-03-15', '3101234568', 'Avenida 20 # 1-10'),
('2003', 'Valentina', 'Andrea', 'Rojas', 'Díaz', '2005-11-01', '3101234569', 'Carrera 7 # 15-B'),
('2004', 'Felipe', NULL, 'Herrera', 'Arias', '1975-01-25', '3101234570', 'Diagonal 30 # 8-A'),
('2005', 'Daniela', 'Carolina', 'Muñoz', 'Vega', '1999-09-10', '3101234571', 'Transversal 50 # 12-30'),
('2006', 'Javier', NULL, 'Ramos', 'León', '1988-04-18', '3101234572', 'Calle 90 # 1-D'),
('2007', 'Luisa', 'María', 'Quintero', 'Gil', '1992-06-05', '3101234573', 'Avenida Principal 45'),
('2008', 'Camilo', NULL, 'Giraldo', 'Paz', '1965-12-30', '3101234574', 'Carrera 15 # 60-C'),
('2009', 'Natalia', 'Isabel', 'Vargas', 'Soto', '2000-02-14', '3101234575', 'Transversal 70 # 2-F'),
('2010', 'Óscar', NULL, 'Mendoza', 'Cruz', '1970-10-10', '3101234576', 'Calle 50 # 3-B'),
('2011', 'Paula', 'Andrea', 'Torres', 'Pérez', '1993-05-22', '3101234577', 'Diagonal 90 # 10-A'),
('2012', 'Sebastián', NULL, 'Rueda', 'Castro', '1986-08-08', '3101234578', 'Carrera 8 # 5-10'),
('2013', 'Sofía', 'Fernanda', 'López', 'Mesa', '2001-04-17', '3101234579', 'Calle 120 # 30-C'),
('2014', 'Héctor', NULL, 'Chávez', 'Arias', '1979-02-28', '3101234580', 'Avenida Las Palmas 5'),
('2015', 'Mariana', 'Alejandra', 'Vidal', 'León', '1997-11-25', '3101234581', 'Barrio San Juan 15');

INSERT INTO Medicos (n_colegiado, nombre1, nombre2, apellido1, apellido2, telefono, id_especialidad) VALUES
('MC1001', 'Dr. Juan', NULL, 'Restrepo', 'Silva', '3209876501', 1), -- 
('MC1002', 'Dra. Ana', 'María', 'Martínez', 'Ríos', '3209876502', 2), -- 
('MC1003', 'Dr. Pedro', NULL, 'Gómez', 'Vargas', '3209876503', 3), -- 
('MC1004', 'Dra. Sofía', NULL, 'Díaz', 'López', '3209876504', 4), -- 
('MC1005', 'Dr. Luis', 'Fernando', 'Pérez', 'Gil', '3209876505', 5), -- 
('MC1006', 'Dra. Elena', NULL, 'Castro', 'Rojas', '3209876506', 6),  
('MC1007', 'Dr. Miguel', 'Ángel', 'Vásquez', 'Cruz', '3209876507', 7),
('MC1008', 'Dra. Paula', NULL, 'Sánchez', 'Mora', '3209876508', 8),
('MC1009', 'Dr. Carlos', NULL, 'Zúñiga', 'Paz', '3209876509', 9), 
('MC1010', 'Dra. Jessica', 'Andrea', 'Torres', 'León', '3209876510', 10), 
('MC1011', 'Dr. Andrés', NULL, 'Gutiérrez', 'Mendoza', '3209876511', 11), 
('MC1012', 'Dra. Claudia', 'Patricia', 'Quintero', 'Soto', '3209876512', 12), 
('MC1013', 'Dr. Guillermo', NULL, 'Ochoa', 'Vidal', '3209876513', 13), 
('MC1014', 'Dra. Mónica', NULL, 'Chávez', 'Rueda', '3209876514', 14), 
('MC1015', 'Dr. Fabián', 'Ricardo', 'Lara', 'Bravo', '3209876515', 15); 

INSERT INTO Citas (id_paciente, id_medico, fecha_hora, motivo, diagnostico) VALUES
(1, 1, '2025-11-15 10:00:00', 'Chequeo de rutina', 'Paciente sano, sin novedad.'),
(2, 2, '2025-11-15 11:30:00', 'Revisión lunar en espalda', 'Nevus común. Cita de seguimiento en 6 meses.'),
(3, 3, '2025-11-16 09:00:00', 'Vacunación y control de peso', 'Vacuna aplicada correctamente.'),
(4, 4, '2025-11-16 14:00:00', 'Dolores de cabeza recurrentes', 'Migraña común. Se recetan analgésicos.'),
(5, 5, '2025-11-17 16:30:00', 'Examen ginecológico anual', 'Resultados normales.'),
(6, 6, '2025-11-18 08:30:00', 'Limpieza dental y revisión', 'Caries menor detectada, agendar empaste.'),
(7, 7, '2025-11-18 12:00:00', 'Consulta por dolor lumbar', 'Lumbalgia aguda. Terapia física y reposo.'),
(8, 8, '2025-11-19 15:00:00', 'Revisión de vista y cambio de lentes', 'Astigmatismo. Lentes recetados.'),
(9, 9, '2025-11-20 10:30:00', 'Seguimiento de fractura de tobillo', 'Proceso de curación favorable.'),
(10, 10, '2025-11-21 11:00:00', 'Consulta de terapia conductual', 'Progreso estable.'),
(11, 11, '2025-11-22 13:00:00', 'Gripa y malestar general', 'Resfriado común. Reposo y líquidos.'),
(12, 12, '2025-11-25 14:30:00', 'Control de glucosa en sangre', 'Niveles estables con medicación.'),
(13, 13, '2025-11-26 10:00:00', 'Acidez estomacal y reflujo', 'Gastritis leve. Dieta suave y antiácidos.'),
(14, 14, '2025-11-27 11:00:00', 'Inicio de terapia física post-cirugía', 'Primera sesión completada.'),
(15, 15, '2025-11-28 09:30:00', 'Dolor de oído y garganta', 'Otitis. Antibióticos recetados.');

SELECT nombre1, apellido1, n_colegiado FROM Medicos ORDER BY apellido1;
SELECT nombre1, apellido1, fecha_nacimiento FROM Pacientes WHERE fecha_nacimiento > '2000-12-31';
SELECT m.nombre1, m.apellido1, e.nombre_especialidad FROM Medicos m JOIN Especialidades e ON m.id_especialidad = e.id_especialidad;
SELECT nombre1, apellido1, telefono_paciente FROM Pacientes WHERE n_identificacion = '2005';
SELECT id_cita, fecha_hora, motivo FROM Citas WHERE id_medico = 3;
SELECT telefono_paciente FROM Pacientes WHERE id_paciente = 12;
SELECT id_cita, fecha_hora FROM Citas WHERE diagnostico = 'Resultados normales.';
SELECT DISTINCT p.nombre1, p.apellido1 FROM Pacientes p JOIN Citas c ON p.id_paciente = c.id_paciente JOIN Medicos m ON c.id_medico = m.id_medico JOIN Especialidades e ON m.id_especialidad = e.id_especialidad WHERE e.nombre_especialidad = 'Pediatría';
SELECT nombre1, apellido1 FROM Medicos m JOIN Especialidades e ON m.id_especialidad = e.id_especialidad WHERE e.nombre_especialidad = 'Dermatología';
SELECT id_cita, fecha_hora, motivo FROM Citas ORDER BY fecha_hora DESC;



