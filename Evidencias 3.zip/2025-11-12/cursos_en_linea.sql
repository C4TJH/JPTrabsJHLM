
CREATE DATABASE IF NOT EXISTS Sistema_Cursos_Online;
USE Sistema_Cursos_Online;

CREATE TABLE IF NOT EXISTS Instructor (
    id_instructor INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    especialidad VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS Estudiante (
    id_estudiante INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Curso (
    id_curso INT PRIMARY KEY AUTO_INCREMENT,
    nombre_curso VARCHAR(100) NOT NULL,
    duracion INT NOT NULL,
    id_instructor INT NOT NULL,
    CONSTRAINT fk_curso_instructor FOREIGN KEY (id_instructor)
        REFERENCES Instructor(id_instructor)
);

CREATE TABLE IF NOT EXISTS Inscripcion (
    id_inscripcion INT PRIMARY KEY AUTO_INCREMENT,
    fecha DATE NOT NULL,
    id_estudiante INT NOT NULL,
    id_curso INT NOT NULL,
    CONSTRAINT fk_inscripcion_estudiante FOREIGN KEY (id_estudiante) REFERENCES Estudiante(id_estudiante),
    CONSTRAINT fk_inscripcion_curso FOREIGN KEY (id_curso) REFERENCES Curso(id_curso)
);


INSERT INTO Instructor (nombre, especialidad) VALUES
('Dr. Alan Turing', 'Criptografía y Lógica'),
('Dra. Ada Lovelace', 'Programación Avanzada'),
('Mtro. Guido van Rossum', 'Python y Desarrollo Web'),
('Ing. Grace Hopper', 'Bases de Datos SQL'),
('Lic. Linus Torvalds', 'Sistemas Operativos y Linux');

INSERT INTO Estudiante (nombre, correo) VALUES
('Elena Ríos', 'elena.rios@mail.com'),
('Marco Soto', 'marco.soto@mail.com'),
('Ana García', 'ana.garcia@mail.com'),
('Pablo Méndez', 'pablo.mendez@mail.com'),
('Sofía Torres', 'sofia.torres@mail.com'),
('Ricardo Vidal', 'ricardo.vidal@mail.com'),
('Luisa Cruz', 'luisa.cruz@mail.com'),
('Jorge Pérez', 'jorge.perez@mail.com'),
('Camila Díaz', 'camila.diaz@mail.com'),
('Héctor Ramos', 'hector.ramos@mail.com');

INSERT INTO Curso (nombre_curso, duracion, id_instructor) VALUES
('Introducción a SQL', 40, 4),
('Estructuras de Datos', 60, 2),
('Algoritmos Avanzados', 80, 2),
('Fundamentos de Python', 30, 3),
('Teoría de la Computación', 50, 1),
('Bases de Datos Relacionales', 45, 4),
('Gestión de Memoria en C', 35, 5);

INSERT INTO Inscripcion (fecha, id_estudiante, id_curso) VALUES
('2025-09-01', 1, 1),
('2025-09-01', 1, 4),
('2025-09-01', 2, 1),
('2025-09-05', 3, 2),
('2025-09-05', 4, 3),
('2025-09-10', 5, 4),
('2025-09-10', 6, 1),
('2025-09-15', 7, 5),
('2025-09-15', 8, 6),
('2025-09-20', 9, 3),
('2025-09-20', 10, 7),
('2025-09-25', 2, 4),
('2025-09-25', 3, 6),
('2025-10-01', 4, 1),
('2025-10-01', 5, 2);

-- CONSULTAS
SELECT nombre, especialidad FROM Instructor ORDER BY nombre ASC;
SELECT nombre_curso, duracion FROM Curso WHERE duracion > 50;
SELECT correo FROM Estudiante WHERE id_estudiante = 5;
SELECT i.nombre AS Instructor_Nombre, c.nombre_curso FROM Instructor i JOIN Curso c ON i.id_instructor = c.id_instructor WHERE c.nombre_curso = 'Fundamentos de Python';
SELECT e.nombre AS Nombre_Estudiante FROM Estudiante e JOIN Inscripcion ins ON e.id_estudiante = ins.id_estudiante JOIN Curso c ON ins.id_curso = c.id_curso WHERE c.nombre_curso = 'Introducción a SQL';
SELECT c.nombre_curso, c.duracion FROM Curso c JOIN Instructor i ON c.id_instructor = i.id_instructor WHERE i.nombre = 'Dra. Ada Lovelace';
SELECT c.nombre_curso, COUNT(ins.id_inscripcion) AS Total_Inscritos FROM Curso c JOIN Inscripcion ins ON c.id_curso = ins.id_curso GROUP BY c.id_curso ORDER BY Total_Inscritos DESC;
SELECT i.nombre AS Instructor, COUNT(c.id_curso) AS Cursos_Dictados FROM Instructor i LEFT JOIN Curso c ON i.id_instructor = c.id_instructor GROUP BY i.id_instructor;
SELECT e.nombre AS Estudiante_Multicurso, COUNT(ins.id_curso) AS Cursos_Totales FROM Estudiante e JOIN Inscripcion ins ON e.id_estudiante = ins.id_estudiante GROUP BY e.id_estudiante HAVING COUNT(ins.id_curso) > 1;
SELECT e.nombre AS Estudiante, c.nombre_curso, ins.fecha FROM Estudiante e JOIN Inscripcion ins ON e.id_estudiante = ins.id_estudiante JOIN Curso c ON ins.id_curso = c.id_curso WHERE e.nombre = 'Elena Ríos' ORDER BY ins.fecha;